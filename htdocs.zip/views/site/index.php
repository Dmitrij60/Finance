<?php if (file_exists('./views/layouts/header.php')) include(ROOT . './views/layouts/header.php'); ?>
<main role="main" class="container">
    <br> <br> <br>
    <div class="starter-template">
        <div class="central-block" style="width:100%; margin: auto; text-align:center;">
            <h1>Finance</h1>
        </div>
    </div>
</main>
<?php if (file_exists('./views/layouts/footer.php')) include(ROOT . '/views/layouts/footer.php'); ?>
