<?php
return array(
    'host' => 'localhost',
    'dbname' => 'finance',
    'user' => 'root',
    'password' => '',
);